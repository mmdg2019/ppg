Employee Late Check-in Penalty v14
==================================
Employee Late Check-in

Installation
============
	- www.odoo.com/documentation/14.0/setup/install.html
	- Install our custom addon

Configuration
=============

    No additional configurations needed

Credits
=======
    Developer: Ijaz Ahammed v13 @ cybrosys, Contact: odoo@cybrosys.com
                 Minhaj v14 @ cybrosys, Contact: odoo@cybrosys.com

